package org.example;

public interface Graphics {
    void drawText(String text);
    void drawHorizontalLine(int length);

    void drawCircle(int radius);
//    void drawVerticalLine(int length);
}
