package org.example;

public interface Shape {
    void draw(Graphics g);
}