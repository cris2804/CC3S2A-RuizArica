package org.example;

public interface DrawingStrategy {
    void draw(Graphics g);
}
