package org.example;

public class RightArrowTest {
}
